import os

RESET  = '\033[37m'
GREEN  = '\033[32m'
RED    = '\033[31m'
YELLOW = '\033[33m'

sky    = YELLOW + "                ☼"
ground = GREEN + "mmMWmwmMwwmmMWwmwmmMm"
stem   = GREEN + "          |"
leaf_r = GREEN + "          |Ꟈ"
leaf_l = GREEN + "         Ꞡ|"

states = {
    0: [
        GREEN + "          ░",
        stem,
    ],
    1: [
        GREEN + "         ʅ░ʃ",
        stem,
        stem,
    ],
    2: [
        GREEN + "        ♦" + RED + "ὠ" + GREEN + "▲" + RED + "ὠ" + GREEN + "♦",
        GREEN + "        ʅ▼▒▼ʃ",
        stem,
        leaf_l,
        stem,
    ],
    3: [
        GREEN + "        ▐" + RED + "▒₩▒" + GREEN + "▌",
        GREEN + "        ʅ▼▒▼ʃ",
        stem,
        stem,
        leaf_l,
        stem,
    ],
    4: [
        RED   + "        ▒₩▒₩▒",
        GREEN + "        ▐" + RED + "▒▒▒" + GREEN + "▌",
        GREEN +  "        ʅ▼▒▼ʃ",
        stem,
        leaf_r,
        stem,
        leaf_l,
        stem,
    ],
    5: [
        RED   + "       ˽╓ɯ▄₩╖˽",
        RED   + "       ʅⱯ▓₦▓Ɐʃ",
        GREEN + "        ▐" + RED + "▓▓▓" + GREEN + "▌",
        GREEN + "        ʅ▼▒▼ʃ",
        stem,
        leaf_r,
        leaf_l,
        stem,
        leaf_r,
        stem,
    ]
}


def show_state(n: int):
    print(sky)
    for line in states[n]:
        print(line)
    print(ground)
    print(RESET)

os.system('cls')
show_state(0)
show_state(1)
show_state(2)
show_state(3)
show_state(4)
show_state(5)
