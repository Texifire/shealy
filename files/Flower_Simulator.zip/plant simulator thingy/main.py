#Shealy C.
#Plant/flower growing simulation programmed Ai-less for fun. Yippie !!!

# ~~~~~-<( Text Bin )>-~~~~~ 

# ~~~~~-<( Importing Libraries )>-~~~~~  
import random as r
import os
import hashlib as h
from plant_graph import *


# ~~~~~-<( Code )>-~~~~~ 
os.system('cls')

def do_day():
    def rain():
        rain_c = r.randrange(1,101)
        if rain_c <= 25:
            return True
        else:
            return False

    def sun():
        sun_amt = r.randrange(0,14)
        return sun_amt
    
    a = rain()
    b = sun()

    if a == True:
        water_amt = 5
        if b > 2:
            sun_amt = b
            sun_amt -= 2
        else:
            sun_amt = 2
    else:
        water_amt = 0
        sun_amt = b
    

    return water_amt, sun_amt

water_amt = 5
plant_stage = 0
plant_nutrients = 0
plant_health = 2
day = 1
death_cnt = 0

def main():
    global water_amt, plant_stage, day, plant_nutrients, plant_health
    water, sun = do_day()

    water_amt += water

    if sun >= 1:
        plant_nutrients += 1

    if plant_nutrients >= 1 and water_amt >= 1:
        plant_nutrients -= 1
        if plant_health < 10:
            plant_health += 1
    elif plant_health >= 1:
        plant_health -= 1

    if plant_health == 10:
        if plant_stage < 5:
            plant_stage += 1
            plant_health = 2
    

    print('Day '+str(day))
    show_state(plant_stage)
    
    if water == 0:
        print("\033[34m☹ Sorry no rain today ☹")
    else:
        print('\033[34m☺ Yay we got rain today ☺')

    print('')
    
    if sun > 0:
        print('\033[33m☺ Yay we got sun today ☺')
    else:
        print("\033[33m☹ The day was very cloudy ☹")

    print('')
  
    print('\033[37mAmount of Water : [ ' + str(water_amt) + ' ] Plants Overall Condition (1-10) : [ ' + str(plant_health) + ' ]')
    a = input('PRESS ENTER TO CONTINUE')
    
    water_amt -= 1
    day += 1
    
running = True
while running == True:
    os.system('cls')
    main()

    
