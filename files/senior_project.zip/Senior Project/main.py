import tkinter as tk
from sripts.menu import Menu
from sripts.hr import HR
from sripts.order import Orders
import sqlite3


def start_data(menu_obj, hr_obj):
    bakery_items = [
        ("Croissant", 3.50, "gluten, dairy"),
        ("Chocolate Cake", 5.99, "gluten, dairy"),
        ("Blueberry Muffin", 2.75, "gluten"),
        ("Bagel", 2.00, "gluten"),
        ("Donut", 1.50, "gluten, dairy"),
        ("Cinnamon Roll", 3.25, "gluten, dairy"),
        ("Apple Pie Slice", 4.50, "gluten"),
        ("Cheesecake", 5.50, "gluten, dairy"),
        ("Brownie", 2.25, "gluten, dairy"),
        ("Cupcake", 2.75, "gluten, dairy"),
        ("Scone", 2.95, "gluten, dairy"),
        ("Banana Bread", 3.00, "gluten"),
        ("Coffee", 1.99, "none"),
        ("Latte", 3.99, "dairy"),
        ("Espresso", 2.49, "none")
    ]

    for name, cost, allergies in bakery_items:
        menu_obj.cursor.execute("""
            INSERT INTO menu_items (name, cost, allergies)
            SELECT ?, ?, ?
            WHERE NOT EXISTS (
                SELECT 1 FROM menu_items WHERE LOWER(name) = LOWER(?)
            )
        """, (name, cost, allergies, name))

    employees = [
        ("John", "Smith"),
        ("Emily", "Johnson"),
        ("Michael", "Brown"),
        ("Sarah", "Davis"),
        ("David", "Wilson")
    ]

    for fname, lname in employees:
        hr_obj.cursor.execute("""
            INSERT INTO employees (fname, lname)
            SELECT ?, ?
            WHERE NOT EXISTS (
                SELECT 1 FROM employees 
                WHERE LOWER(fname) = LOWER(?) AND LOWER(lname) = LOWER(?)
            )
        """, (fname, lname, fname, lname))

    menu_obj.conn.commit()
    hr_obj.conn.commit()


def main():
    conn = sqlite3.connect("bakery.db", timeout=10)

    menu_obj = Menu(conn)
    hr_obj = HR(conn)
    order_obj = Orders(conn)

    start_data(menu_obj, hr_obj)

    root = tk.Tk()
    root.title("Bakery Management Dashboard")
    root.geometry("400x400")

    tk.Label(root, text="MAIN DASHBOARD", font=("Arial", 16)).pack(pady=20)

    tk.Button(root, text="Menu Dashboard", width=25,
              command=lambda: Menu.open_menu_window(menu_obj)).pack(pady=5)

    tk.Button(root, text="HR Dashboard", width=25,
              command=lambda: HR.open_hr_window(hr_obj)).pack(pady=5)

    tk.Button(root, text="Orders Dashboard", width=25,
              command=lambda: Orders.open_orders_window(order_obj)).pack(pady=5)

    tk.Button(root, text="Exit", width=25, command=root.quit).pack(pady=20)

    root.mainloop()

if __name__ == "__main__":
    main()