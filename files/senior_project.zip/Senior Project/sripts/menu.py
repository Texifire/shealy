import sqlite3
import tkinter as tk
from tkinter import ttk

class Menu:
    
    def __init__(self, conn):
        
        self.conn = conn
        self.cursor = conn.cursor()

    def open_menu_window(menu_obj):
        window = tk.Toplevel()
        window.title("Menu Dashboard")
        window.geometry("600x400")

        tk.Label(window, text="Menu Items", font=("Arial", 14)).pack(pady=10)

        columns = ("ID", "Name", "Cost", "Allergies")

        tree = ttk.Treeview(window, columns=columns, show="headings")

        for col in columns:
            tree.heading(col, text=col)
            tree.column(col, anchor="center")

        tree.pack(fill="both", expand=True)

        def load_menu():
            tree.delete(*tree.get_children())
            menu_obj.cursor.execute("SELECT * FROM menu_items")
            items = menu_obj.cursor.fetchall()

            for item in items:
                tree.insert("", "end", values=item)

        def add_item():
            add_win = tk.Toplevel()
            add_win.title("Add Item")

            tk.Label(add_win, text="Name").pack()
            name = tk.Entry(add_win)
            name.pack()

            tk.Label(add_win, text="Cost").pack()
            cost = tk.Entry(add_win)
            cost.pack()

            tk.Label(add_win, text="Allergies").pack()
            allergies = tk.Entry(add_win)
            allergies.pack()

            def save():
                menu_obj.cursor.execute(
                    "INSERT INTO menu_items (name, cost, allergies) VALUES (?, ?, ?)",
                    (name.get(), cost.get(), allergies.get())
                )
                menu_obj.conn.commit()
                load_menu()
                add_win.destroy()

            tk.Button(add_win, text="Save", command=save).pack()

        def delete_item():
            selected = tree.selection()
            if not selected:
                return

            item = tree.item(selected[0])
            item_id = item["values"][0]

            menu_obj.cursor.execute(
                "DELETE FROM menu_items WHERE id = ?",
                (item_id,)
            )
            menu_obj.conn.commit()

            load_menu()

        tk.Button(window, text="Refresh", command=load_menu).pack(pady=5)
        tk.Button(window, text="Add Item", command=add_item).pack(pady=5)
        tk.Button(window, text="Delete Selected Item", command=delete_item).pack(pady=5)

        load_menu()
