import sqlite3
import tkinter as tk
from tkinter import ttk, messagebox

class Orders:
    
    def __init__(self, conn):
        self.conn = conn
        self.cursor = conn.cursor()

    def open_orders_window(order_obj):
        window = tk.Toplevel()
        window.title("POS System")
        window.geometry("800x500")

        cart = []
        total_cost = tk.DoubleVar(value=0.0)

        left_frame = tk.Frame(window)
        left_frame.pack(side="left", fill="both", expand=True, padx=10, pady=10)

        tk.Label(left_frame, text="Menu", font=("Arial", 14)).pack()

        menu_list = tk.Listbox(left_frame, height=20)
        menu_list.pack(fill="both", expand=True)

        order_obj.cursor.execute("SELECT name, cost, allergies FROM menu_items")
        items = order_obj.cursor.fetchall()

        def load_menu_items():
            menu_list.delete(0, tk.END)
            order_obj.cursor.execute("SELECT name, cost, allergies FROM menu_items")
            updated_items = order_obj.cursor.fetchall()

            items.clear()
            items.extend(updated_items)

            for item in updated_items:
                name, cost, allergies = item
                menu_list.insert(
                    tk.END,
                    f"{name} - ${cost:.2f} | Allergies: {allergies}"
                )

        load_menu_items()

        right_frame = tk.Frame(window)
        right_frame.pack(side="right", fill="both", expand=True, padx=10, pady=10)

        tk.Label(right_frame, text="Cart", font=("Arial", 14)).pack()

        cart_list = tk.Listbox(right_frame, height=15)
        cart_list.pack(fill="both", expand=True)

        total_label = tk.Label(right_frame, text="Total: $0.00", font=("Arial", 12))
        total_label.pack(pady=10)

        tk.Label(right_frame, text="Customer Email").pack()
        email_entry = tk.Entry(right_frame, width=30)
        email_entry.pack(pady=5)

        def add_to_cart():
            selection = menu_list.curselection()
            if not selection:
                return

            index = selection[0]
            name, cost, allergies = items[index]

            cart.append((name, cost, allergies))

            cart_list.insert(
                tk.END,
                f"{name} - ${cost:.2f} | Allergies: {allergies}"
            )

            new_total = total_cost.get() + cost
            total_cost.set(new_total)
            total_label.config(text=f"Total: ${new_total:.2f}")

        def remove_from_cart():
            selected = cart_list.curselection()
            if not selected:
                return

            index = selected[0]
            name, cost, allergies = cart[index]

            cart.pop(index)
            cart_list.delete(index)

            new_total = total_cost.get() - cost
            total_cost.set(new_total)
            total_label.config(text=f"Total: ${new_total:.2f}")

        def checkout():
            if not cart:
                messagebox.showwarning("Empty Cart", "No items in cart")
                return

            email = email_entry.get().strip()

            if email == "":
                messagebox.showwarning("Missing Email", "Please enter a customer email")
                return

            subtotal = total_cost.get()
            tax = subtotal * 0.07
            final_total = subtotal + tax

            item_names = [item[0] for item in cart]

            order_obj.cursor.execute(
                "INSERT INTO orders (email, items, total) VALUES (?, ?, ?)",
                (email, ", ".join(item_names), final_total)
            )
            order_obj.conn.commit()

            messagebox.showinfo(
                "Order Complete",
                f"Email: {email}\nSubtotal: ${subtotal:.2f}\nTax: ${tax:.2f}\nTotal: ${final_total:.2f}"
            )

            cart.clear()
            cart_list.delete(0, tk.END)
            total_cost.set(0.0)
            total_label.config(text="Total: $0.00")
            email_entry.delete(0, tk.END)

        def view_orders():
            history_window = tk.Toplevel()
            history_window.title("Order History")
            history_window.geometry("700x400")

            tk.Label(history_window, text="Order History", font=("Arial", 14)).pack(pady=10)

            columns = ("ID", "Email", "Items", "Total")

            tree = ttk.Treeview(history_window, columns=columns, show="headings")

            for col in columns:
                tree.heading(col, text=col)
                tree.column(col, anchor="center")

            tree.pack(fill="both", expand=True)

            order_obj.cursor.execute("SELECT * FROM orders ORDER BY id DESC")
            orders = order_obj.cursor.fetchall()

            for order in orders:
                tree.insert("", "end", values=order)

        tk.Button(left_frame, text="Add to Cart", command=add_to_cart).pack(pady=5)
        tk.Button(left_frame, text="Refresh Menu", command=load_menu_items).pack(pady=5)

        tk.Button(right_frame, text="Remove Selected Item", command=remove_from_cart).pack(pady=5)
        tk.Button(right_frame, text="Checkout", command=checkout).pack(pady=10)
        tk.Button(right_frame, text="View Order History", command=view_orders).pack(pady=5)