import sqlite3
from datetime import datetime
import tkinter as tk
from tkinter import ttk


class HR:

    def __init__(self, conn):
        self.conn = conn
        self.cursor = conn.cursor()
        self.create_tables()

    def create_tables(self):
        self.cursor.execute("""
        CREATE TABLE IF NOT EXISTS employees (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            fname TEXT,
            lname TEXT
        )
        """)

        self.cursor.execute("""
        CREATE TABLE IF NOT EXISTS time_logs (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            employee_id INTEGER,
            clock_in TEXT,
            clock_out TEXT,
            weeks_hours REAL
        )
        """)

        self.conn.commit()

    def open_hr_window(hr_obj):
        window = tk.Toplevel()
        window.title("HR Dashboard")
        window.geometry("800x600")

        tk.Label(window, text="All Employees", font=("Arial", 14)).pack(pady=5)

        columns = ("ID", "First Name", "Last Name")
        tree = ttk.Treeview(window, columns=columns, show="headings")

        for col in columns:
            tree.heading(col, text=col)
            tree.column(col, anchor="center")

        tree.pack(fill="both", expand=True)

        tk.Label(window, text="Currently Clocked In", font=("Arial", 14)).pack(pady=10)

        clocked_columns = ("Employee ID", "Clock In Time")

        clocked_tree = ttk.Treeview(window, columns=clocked_columns, show="headings")

        for col in clocked_columns:
            clocked_tree.heading(col, text=col)
            clocked_tree.column(col, anchor="center")

        clocked_tree.pack(fill="both", expand=True)

        def load_employees():
            tree.delete(*tree.get_children())

            hr_obj.cursor.execute("SELECT * FROM employees")
            rows = hr_obj.cursor.fetchall()

            for row in rows:
                tree.insert("", "end", values=row)

        def load_clocked_in():
            clocked_tree.delete(*clocked_tree.get_children())

            hr_obj.cursor.execute("""
                SELECT employee_id, clock_in
                FROM time_logs
                WHERE clock_out IS NULL
                ORDER BY clock_in DESC
            """)

            rows = hr_obj.cursor.fetchall()

            for row in rows:
                clocked_tree.insert("", "end", values=row)

        def refresh_all():
            load_employees()
            load_clocked_in()

        def add_employee():
            add_win = tk.Toplevel()
            add_win.title("Add Employee")

            tk.Label(add_win, text="First Name").pack()
            fname = tk.Entry(add_win)
            fname.pack()

            tk.Label(add_win, text="Last Name").pack()
            lname = tk.Entry(add_win)
            lname.pack()

            def save():
                hr_obj.cursor.execute(
                    "INSERT INTO employees (fname, lname) VALUES (?, ?)",
                    (fname.get(), lname.get())
                )
                hr_obj.conn.commit()
                refresh_all()
                add_win.destroy()

            tk.Button(add_win, text="Save", command=save).pack()

        def delete_employee():
            selected = tree.selection()
            if not selected:
                return

            item = tree.item(selected[0])
            emp_id = item["values"][0]

            hr_obj.cursor.execute(
                "DELETE FROM employees WHERE id = ?",
                (emp_id,)
            )
            hr_obj.conn.commit()

            refresh_all()

        clock_frame = tk.LabelFrame(window, text="Time Clock", padx=10, pady=10)
        clock_frame.pack(fill="x", padx=10, pady=10)

        tk.Label(clock_frame, text="Employee ID").grid(row=0, column=0)

        emp_id_entry = tk.Entry(clock_frame)
        emp_id_entry.grid(row=0, column=1)

        def clock_in_gui():
            emp_id = emp_id_entry.get().strip()
            if emp_id == "":
                return

            now = datetime.now()

            hr_obj.cursor.execute(
                "INSERT INTO time_logs (employee_id, clock_in) VALUES (?, ?)",
                (emp_id, now)
            )
            hr_obj.conn.commit()
            load_clocked_in()

        def clock_out_gui():
            emp_id = emp_id_entry.get().strip()
            if emp_id == "":
                return

            now = datetime.now()

            hr_obj.cursor.execute("""
                SELECT id, clock_in FROM time_logs
                WHERE employee_id = ? AND clock_out IS NULL
                ORDER BY id DESC LIMIT 1
            """, (emp_id,))

            record = hr_obj.cursor.fetchone()

            if record:
                log_id, clock_in_time = record
                clock_in_time = datetime.fromisoformat(clock_in_time)

                hours_worked = (now - clock_in_time).total_seconds() / 3600

                hr_obj.cursor.execute("""
                    UPDATE time_logs
                    SET clock_out = ?, weeks_hours = ?
                    WHERE id = ?
                """, (now, hours_worked, log_id))

                hr_obj.conn.commit()
                load_clocked_in()

        tk.Button(clock_frame, text="Clock In", command=clock_in_gui).grid(row=1, column=0, pady=5)
        tk.Button(clock_frame, text="Clock Out", command=clock_out_gui).grid(row=1, column=1, pady=5)

        tk.Button(window, text="Refresh All", command=refresh_all).pack(pady=5)
        tk.Button(window, text="Add Employee", command=add_employee).pack(pady=5)
        tk.Button(window, text="Delete Selected Employee", command=delete_employee).pack(pady=5)

        refresh_all()